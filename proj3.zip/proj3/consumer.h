void* runConsumer (void* param);
