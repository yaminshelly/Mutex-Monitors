void* runSupplier (void* param);
char *change_num_to_day(int x);
char *change_num_to_mounth(int x);
